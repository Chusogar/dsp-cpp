Capturas NeoGeo MVS — dsp-cpp
ROMs: MAME 0.260 non-merged neogeo.zip + mslug.zip
Resolucion: 320x224

## bios/
  030.png  frame 30  BIOS SP-S2, RAM test (pantalla negra/casi vacia)
  060.png  frame 60  BIOS SP-S2, sigue el self-test de memoria
  090.png  frame 90  BIOS SP-S2, palette/VRAM test
  120.png  frame 120  BIOS SP-S2, test de fuente SFIX (columnas de caracteres)
  180.png  frame 180  BIOS SP-S2, espera del pulso 1Hz del RTC (uPD4990A)
  240.png  frame 240  BIOS SP-S2, sigue esperando el segundo flanco TP
  360.png  frame 360  BIOS SP-S2, calendario OK: crosshatch MVS
  after-start.png  tras coin/start: barras RGB (sin cartucho)

## mslug/
  030.png  frame 30  Metal Slug, mismo self-test BIOS
  060.png  frame 60  Metal Slug, self-test de memoria
  090.png  frame 90  Metal Slug, palette/VRAM test
  120.png  frame 120  Metal Slug, test de fuente SFIX; cartucho detectado
  180.png  frame 180  Metal Slug, espera del pulso 1Hz del RTC
  240.png  frame 240  Metal Slug, sigue el chequeo de calendario
  360.png  frame 360  Metal Slug, self-test OK (transicion gris)
  after-start.png  tras coin/start: how-to-play Metal Slug (pc=$051fd0)

